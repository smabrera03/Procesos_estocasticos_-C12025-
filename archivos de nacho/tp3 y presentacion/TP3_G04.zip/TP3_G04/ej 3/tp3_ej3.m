%% Ejercicio 3
clc; clear vars; close all;
P = 20;

generar_graficos("e.wav", " M = 10 [e]", P, 10);
generar_graficos("sh.wav", " M = 10 [sh]", P, 10);

generar_graficos("e.wav", " M = 100 [e]", P, 100);
generar_graficos("sh.wav", " M = 100 [sh]", P, 100);

generar_graficos("e.wav", " M = 1000 [e]", P, 1000);
generar_graficos("sh.wav", " M = 1000 [sh]", P, 1000);

function generar_graficos(audio, leyenda, P, M)
    % Leo el archivo
    x = audioread(audio);

    % Estimo los parametros
    [a, G] = param_ar(x, P);
    disp(a);
    disp(G);
    
    % Computo las PSD teorica segun la teoria estudiada
    w = linspace(0, 2*pi, length(x)); %vector de frecuencias
    Sxteo = power(G, 2)*power(abs(freqz(1, [1 -transpose(a)], w)), 2);
    
    %Periodograma estimado por Welch
    [welch,frecs] = Welch_alt(x, M, 0.5,10); 
    
    % Generamos los graficos en dB
    fig_sx = figure();
    plot(frecs, 20*log10(welch));
    hold;
    plot(w, 20*log10(Sxteo), "linewidth", 3);
    grid on;
    title(strcat("Densidad espectral de potencia ", leyenda));   
    legend("Periodograma", "Teorico")
    set(gca,"fontsize", 10);
    ylabel('Sx [dB]');
    xlabel('Pulsacion [rad/s]');
    xlim([0 pi]);
    %saveas(fig_sx, strcat(leyenda, strcat("_sx_welch.png")))
end

function [a, G] = param_ar(x, P)
    %estimo la autocorrelacion a partir de las muestas x
    [Rx, lags] = xcorr(x, "biased");
    
    %busco el elemento de r donde esta ubicado Rx(0)
    cero = find(lags == 0);
    
    %Uso el vector hasta P valores
    %recordando que Rx es una funcion par considerando el proceso ESA
    Rx = Rx(cero:cero+P); 
    r = Rx(2:P+1);
    
    %Armo la matriz R con las autocorrelaciones
    R = zeros(P, P);
    for i = 1:1:P
        %Genero un vector y completo todos sus
        %elementos con Rx(i)
        v = Rx(i).*transpose(ones(P+1-i, 1));
        %inserto el vector en la diagonal correspondiente
        if i == 1
            R = R + diag(v, i-1);
        else
            R = R + diag(v, i-1) +  diag(v, -(i-1));
        end  
    end
    %Estimo los parametros
    a = inv(R)*r;
    
    %Estimo la ganancia
    G = sqrt(Rx(1) - transpose(a)*r); 
end

function [welch,frecs] = Welch_alt(X, M, overlap_percent,z_padd_coef)
    
    % Reordenamos la realizacion en realizaciones de M muestras con el 
    % overlap correspondiente. Para reducir la correlacion entre
    % ventanas subsiguientes, reducimos el peso de los extremos con una
    % ventana de hamming
    X_reshaped= buffer(X, M, overlap_percent*M).*hamming(M);    

    P = mean( power(transpose(hamming(M)),2)); %calculamos la potencia de la ventana, se usa en la estimación del periodograma welch
    

    % Computamos la fft para cada realizacion con zero padding
    FFT_matrix=fft(X_reshaped,M*z_padd_coef);
    
    % Computamos el periodograma de cada realizacion y tomamos la media 
    welch = mean((1/(M*P)).*power(abs(FFT_matrix),2),2);
    frecs = linspace(0,2*pi, length(welch));
end