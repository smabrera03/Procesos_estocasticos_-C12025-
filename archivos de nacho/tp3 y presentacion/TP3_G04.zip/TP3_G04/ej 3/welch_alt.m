
function [A] = Periodograma(X,N)
    A = (1/N)* power(abs(fft(X,N)),2); %periodograma 
end

function [barlett,frecs] = Barlett_alt(X,M)
    L=length(X)/M;
    X_reshaped= reshape(X,L,M);
    FFT_matrix=fft(X_reshaped);
    barlett = mean((1/M)* power(abs(FFT_matrix),2),2); %periodograma 
    frecs = linspace(0,2*pi,length(barlett));
end

function [welch,frecs] = Welch_alt(X,M,overlap_percent)
    L=length(X)/M;
    X_reshaped= hann(M) .* buffer(X,M,overlap_percent*M);    
    FFT_matrix=fft(X_reshaped);
    welch = mean((1/M)* power(abs(FFT_matrix),2),2); %periodograma 
    frecs = linspace(0,2*pi,length(welch));
end

