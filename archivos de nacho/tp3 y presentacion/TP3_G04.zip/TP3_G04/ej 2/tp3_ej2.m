%% Ejercicio 2 a y b
clc; clear vars; close all;
P = 20;

%genera grafs de todos los fonemas
generar_graficos("a.wav", "[a]", P);
generar_graficos("e.wav", "[e]", P);
generar_graficos("f.wav", "[f]", P);
generar_graficos("i.wav", "[i]", P);
generar_graficos("j.wav", "[j]", P);
generar_graficos("o.wav", "[o]",P);
generar_graficos("s.wav", "[s]",P);
generar_graficos("sh.wav", "[sh]",P);
generar_graficos("u.wav", "[u]",P);

function generar_graficos(audio, leyenda, P)
    % Leo el archivo
    x = audioread(audio);

    % Estimo los parametros
    [a, G] = param_ar(x, P);
    disp(a);
    disp(G);

    % Computo las PSD teorica segun la teoria estudiada
    [Rx, lags] = xcorr(x, "biased");
    w = linspace(0, 2*pi, length(x)); %vector de frecuencias
    Sxteo = power(G, 2)*power(abs(freqz(1, [1 transpose(-a)], w)), 2);

    % Periodograma a partir de la fft de la señal
    Sx = (1/length(x))*power(abs(fft(x)), 2); %Periodograma
    
    % Generamos los graficos
    fig_respuesta = figure();
    plot(x);
    grid on;
    title(strcat("Respuesta temporal ", leyenda));
    set(gca,"fontsize", 10);
    xlabel('n');
    xlim([0 400]);
    %saveas(fig_respuesta, strcat(leyenda, strcat("_respuesta.png")))

    fig_rx =figure();
    stem(lags, Rx);
    grid on;
    title(strcat("Autocorrelacion ", leyenda));   
    set(gca,"fontsize", 10);
    xlabel('k');
    xlim([-100 100]);
    %saveas(fig_rx, strcat(leyenda, strcat("_rx.png")))

    fig_sx = figure();
    plot(w, 20*log10(Sx));
    hold;
    plot(w, 20*log10(Sxteo), "linewidth", 3);
    grid on;
    title(strcat("Densidad espectral de potencia ", leyenda));   
    legend("Periodograma", "Teorico")
    set(gca,"fontsize", 10);
    ylabel('Sx [dB]');
    xlabel('Pulsacion [rad/s]');
    xlim([0 pi]);
    %saveas(fig_sx, strcat(leyenda, strcat("_sx.png")))
end

function [a, G] = param_ar(x, P)
    %estimo la autocorrelacion a partir de las muestas x
    [Rx, lags] = xcorr(x, "biased");
    
    %busco el elemento de r donde esta ubicado Rx(0)
    cero = find(lags == 0);
    
    %Uso el vector hasta P valores
    %recordando que Rx es una funcion par considerando el proceso ESA
    Rx = Rx(cero:cero+P); 
    r = Rx(2:P+1);
    
    %Armo la matriz R con las autocorrelaciones
    R = zeros(P, P);
    for i = 1:1:P
        %Genero un vector y completo todos sus
        %elementos con Rx(i)
        v = Rx(i).*transpose(ones(P+1-i, 1));
        %inserto el vector en la diagonal correspondiente
        if i == 1
            R = R + diag(v, i-1);
        else
            R = R + diag(v, i-1) +  diag(v, -(i-1));
        end  
    end
    %Estimo los parametros
    a = inv(R)*r;
    
    %Estimo la ganancia
    G = sqrt(Rx(1) - transpose(a)*r); 
end
