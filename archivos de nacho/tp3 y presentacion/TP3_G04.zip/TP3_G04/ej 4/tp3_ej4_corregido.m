%% Ejercicio 4 a y b
clc; clear vars; close all;

% Parámetros generales          
P = 20;
M = 100;
fs = 14700;
duracion = 500e-3;
duracion_vocal = 120e-3; 
duracion_consonante = 70e-3;
N = round(fs * duracion);
pitch = 100; 
pitch_a = 100;
pitch_e = 125;
pitch_i = 150;
pitch_o = 125;
pitch_u = 100;
fade = 40;
z_padd_coef = 10;

%Ejemplos de fonemas sintetizados para el 4a
a_sint_0 = sintetizar_sonora("a.wav",duracion,pitch,fs,P, 0);
s_sint_0 = sintetizar_sorda("s.wav",duracion,fs,P,0);

%Fonemas sintetizados y suavizados
sh_sint = sintetizar_sorda("sh.wav",duracion_consonante,fs,P,fade);
s_sint = sintetizar_sorda("s.wav",duracion_consonante,fs,P,fade);
f_sint = sintetizar_sorda("f.wav",duracion_consonante,fs,P,fade);
j_sint = sintetizar_sorda("j.wav",duracion_consonante,fs,P,fade);

%Mismo pitch
a_sint = sintetizar_sonora("a.wav",duracion_vocal,pitch,fs,P, fade);
e_sint = sintetizar_sonora("e.wav",duracion_vocal,pitch,fs,P, fade);
i_sint = sintetizar_sonora("i.wav",duracion_vocal,pitch,fs,P, fade);
o_sint = sintetizar_sonora("o.wav",duracion_vocal,pitch,fs,P, fade);
u_sint = sintetizar_sonora("u.wav",duracion_vocal,pitch,fs,P, fade);

%Distinto pitch
a_sint_1 = sintetizar_sonora("a.wav",duracion_vocal, pitch_a ,fs,P, fade);
e_sint_1 = sintetizar_sonora("e.wav",duracion_vocal, pitch_e ,fs,P, fade);
i_sint_1 = sintetizar_sonora("i.wav",duracion_vocal, pitch_i ,fs,P, fade);
o_sint_1 = sintetizar_sonora("o.wav",duracion_vocal, pitch_o ,fs,P, fade);
u_sint_1 = sintetizar_sonora("u.wav",duracion_vocal, pitch_u ,fs,P, fade);

%% 4a: Graficos de los feonemas [a] y [s] 
t = (0:N-1) / fs; 

%Señal temporal [a]
fig_son_sint = figure();
plot(t, a_sint_0);
title('Señal sonora sintetizada');
xlabel('Tiempo (s)');
ylabel('Amplitud');
saveas(fig_son_sint,'[a]_sint.png');

%Señal temporal [s]
fig_sor_sint = figure();
plot(t, s_sint_0);
title('Señal sorda sintetizada');
xlabel('Tiempo (s)');
ylabel('Amplitud');
saveas(fig_sor_sint, '[s]_sint.png');

%Periodograma y PSD teorica
generar_graficos("a.wav",a_sint_0,"a sintetizada",P,M,z_padd_coef);
generar_graficos("s.wav",s_sint_0,"s sintetizada",P,M,z_padd_coef);

%% 4b: Concatenacion de fonemas para la palabra "shafeijous"
%Fonemas sonoro con el mismo pitch
palabra = [sh_sint; a_sint; f_sint; e_sint; i_sint; j_sint; o_sint; u_sint; s_sint];

%Fonemas sonoros son distinto pitch
palabra_pitch = [sh_sint; a_sint_1; f_sint; e_sint_1; i_sint_1; j_sint; o_sint_1; u_sint_1; s_sint];

%Señal temporal palabra "shafeijous"
fig_palabra = figure();    
t = 1:length(palabra); 
plot(t, palabra);
grid on;

%Señal temporal palabra "shafeijous" con distintos pitch
fig_palabra_pitch = figure();
t = 1:length(palabra_pitch); 
plot(t, palabra_pitch);
grid on;

%Periodogramas y PSD teoricas
audiowrite("shafeijous.wav",palabra,fs);
generar_graficos("shafeijous.wav", palabra,"shafeijous",P,M,z_padd_coef);
saveas(fig_palabra, 'shafeijous.png');

audiowrite("shafeijous_pitch.wav",palabra_pitch,fs);
generar_graficos("shafeijous_pitch.wav", palabra_pitch,"shafeijous_pitch",P,M,z_padd_coef);
saveas(fig_palabra_pitch, 'shafeijous_pitch.png');

%% Funciones utilizadas
function generar_graficos(audio_original,x_sint,leyenda, P, M, z_padd_coef)
    
    %son los params estimados del audio original
    [a,G] = param_ar(audioread(audio_original), P);
    
    % Computo las PSD teorica segun la teoria estudiada
    w = linspace(0, 2*pi, length(x_sint)); %vector de frecuencias
    Sxteo = power(G, 2)*power(abs(freqz(1, [1 -transpose(a)], w)), 2);
    
    %hasta acá es la PSD teórica basada en la estimación de params del
    %filtro AR del audio original 


    %Periodograma estimado por Welch
    [welch,frecs] = Welch_alt(x_sint, M, 0.5, z_padd_coef); 
    
    % Generamos los graficos en dB
    fig_sx = figure();
    plot(frecs, 20*log10(welch));
    hold;
    plot(w, 20*log10(Sxteo), "linewidth", 3);
    grid on;
    %title(strcat("Densidad espectral de potencia ", leyenda));   
    legend("Periodograma", "Teorico")
    set(gca,"fontsize", 10);
    ylabel('Sx [dB]');
    xlabel('Pulsacion [rad/s]');
    xlim([0 pi]);
    saveas(fig_sx, strcat(leyenda, strcat("_sx_welch.png")))
end

function [a, G] = param_ar(x, P)
    %estimo la autocorrelacion a partir de las muestas x
    [Rx, lags] = xcorr(x, "biased");
    
    %busco el elemento de r donde esta ubicado Rx(0)
    cero = find(lags == 0);
    
    %Uso el vector hasta P valores
    %recordando que Rx es una funcion par considerando el proceso ESA
    Rx = Rx(cero:cero+P); 
    r = Rx(2:P+1);
    
    %Armo la matriz R con las autocorrelaciones
    R = zeros(P, P);
    for i = 1:1:P
        %Genero un vector y completo todos sus
        %elementos con Rx(i)
        v = Rx(i).*transpose(ones(P+1-i, 1));
        %inserto el vector en la diagonal correspondiente
        if i == 1
            R = R + diag(v, i-1);
        else
            R = R + diag(v, i-1) +  diag(v, -(i-1));
        end  
    end
    %Estimo los parametros
    a = inv(R)*r;
    
    %Estimo la ganancia
     G = sqrt(Rx(1) - transpose(a)*r); 
end

function [welch,frecs] = Welch_alt(X, M, overlap_percent, z_padd_coef)
    
    % Reordenamos la realizacion en realizaciones de M muestras con el 
    % overlap correspondiente. Para reducir la correlacion entre
    % ventanas subsiguientes, reducimos el peso de los extremos con una
    % ventana de hamming
    X_reshaped= buffer(X, M, overlap_percent*M).*hamming(M);    

    P = mean( power(transpose(hamming(M)),2)); %calculamos la potencia de la ventana, se usa en la estimación del periodograma welch
    
    % Computamos la fft para cada realizacion, agregando zero paddin para
    % mas definicion
    FFT_matrix=fft(X_reshaped,M*z_padd_coef);
    
    % Computamos el periodograma de cada realizacion y tomamos la media 
    welch = mean((1/(M*P)).*power(abs(FFT_matrix),2),2);
    frecs = linspace(0,2*pi, length(welch));
end

function x_sonora_sint = sintetizar_sonora(audio_origen, duracion, pitch, fs, P, fade)
    % Parámetros generales          
    % Cantidad de muestras
    N = round(fs * duracion);   
    % Periodo del habla sonora
    T = 1 / pitch;      
    
    % Lectura del archivo
    [x,fa] = audioread(audio_origen);
    % Estimación de parámetros
    [a, G] = param_ar(x, P);

    % Generación de una señal de excitación de tipo sonora: tren de pulsos periodicos.
    exct_sonora = zeros(N, 1); 
    exct_sonora(1:T*fs:end) = sqrt(T*fs);

    % Sintetizo la señal 
    x_sonora_sint = filter(G, [1, -a.'], exct_sonora);

    % Suavizo los bordes y la guardo
    x_sonora_sint = transpose(suavizar_bordes(x_sonora_sint, fade));
    % audiowrite(nuevo_audio_destino, x_sonora, fa);
end

function x_sorda_sint = sintetizar_sorda(audio_origen,duracion,fs,P,fade)
    % Parámetros generales          
    % Cantidad de muestras
    N = round(fs * duracion);    
    
    % Lectura del archivo
    [x, fa] = audioread(audio_origen);
    % Estimación de parámetros
    [a, G] = param_ar(x, P);

    % Generación de una señal de excitación de tipo sorda: ruido blanco.
    exct_sorda = randn(N, 1);

    % Sintetizo la señal y la guardo 
    x_sorda_sint = filter(G, [1, -a.'], exct_sorda);

    x_sorda_sint = transpose(suavizar_bordes(x_sorda_sint, fade));
    %audiowrite(nuevo_audio_destino, x_sorda, fa);
end

function s = suavizar_bordes(x, fade)
    % Suaviza los bordes de una señal
    % x: señal original
    % fade: representa el tiempo de transición como un porcentaje del largo de x
    % s: versión suavizada de x
    M = length(x);
    if fade > 50
        fade = 50;
    elseif fade < 1
        fade = 1;
    end
    if size(x,1)~=1; x = x'; end
    N = 2*floor(fade/100*M);
    v = hamming(N)';
    fade_in = v(1:floor(N/2));
    fade_out = v(floor(N/2)+1:end);
    s = [fade_in ones(1,M-length(v)) fade_out].*x;
end